# gcloud compute instances create ciscfinal --image-project=debian-cloud --zone=us-central1-a --image-family=debian-10 --metadata-from-file=startup-script=./startup.sh
# gcloud compute firewall-rules create rule-allow-tcp-5001 --source-ranges 0.0.0.0/0 --target-tags http-server --allow tcp:5001


# export TODO_API=`gcloud compute instances list --filter="name=ciscfinal" --format="value(EXTERNAL_IP)"`
# next, deploy the app that depens on api
# docker build -t zhouji2018/cisc5550todoapp --build-arg api_ip=${TODO_API} .
# docker build -t cisc-front:v1 --build-arg api_ip=${TODO_API} . 
# docker run -p 80:80 cisc-front:v1
gcloud compute instances create hw3 --project=cisc5550gcloud --zone=us-central1-a --machine-type=e2-medium --network-interface=network-tier=PREMIUM,subnet=default --maintenance-policy=MIGRATE --provisioning-model=STANDARD --service-account=133938927518-compute@developer.gserviceaccount.com --scopes=https://www.googleapis.com/auth/devstorage.read_only,https://www.googleapis.com/auth/logging.write,https://www.googleapis.com/auth/monitoring.write,https://www.googleapis.com/auth/servicecontrol,https://www.googleapis.com/auth/service.management.readonly,https://www.googleapis.com/auth/trace.append --tags=http-server,https-server --create-disk=auto-delete=yes,boot=yes,device-name=hw3,image=projects/debian-cloud/global/images/debian-11-bullseye-v20220406,mode=rw,size=10,type=projects/cisc5550gcloud/zones/us-central1-a/diskTypes/pd-balanced --no-shielded-secure-boot --shielded-vtpm --shielded-integrity-monitoring --reservation-affinity=any

gcloud compute ssh hw3 --zone=us-central1-a --command='
sudo apt install python3-pip
sudo apt-get install wget
sudo pip3 install flask
sudo pip3 install requests
sudo pip3 install urllib3
wget -nc https://raw.githubusercontent.com/dougymenns/cisc5550/main/todolist_api.py
wget -nc https://raw.githubusercontent.com/dougymenns/cisc5550/main/sqlite.py
python3 sqlite.py
python3 todolist_api.py
'




