#!/bin/bash

apt-get update -y
apt-get upgrade -y
apt-get install -y python3-pip
pip3 install --upgrade flask
pip3 install requests
pip3 install urllib3

# download the code
wget https://github.com/dougymenns/cisc5550/blob/main/todolist_api.py
wget https://github.com/dougymenns/cisc5550/blob/main/todolist.db
wget https://github.com/dougymenns/cisc5550/blob/main/users.db

python3 todolist_api.py
