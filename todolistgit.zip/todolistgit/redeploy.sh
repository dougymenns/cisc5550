#/bin/bash
# project name, e.g. 'cisc5550-demo' is up to you
# gcloud compute instances create ciscfinal --project=cisc5550gcloud --zone=us-central1-a --machine-type=e2-medium --network-interface=network-tier=PREMIUM,subnet=default --maintenance-policy=MIGRATE --provisioning-model=STANDARD --service-account=133938927518-compute@developer.gserviceaccount.com --scopes=https://www.googleapis.com/auth/devstorage.read_only,https://www.googleapis.com/auth/logging.write,https://www.googleapis.com/auth/monitoring.write,https://www.googleapis.com/auth/servicecontrol,https://www.googleapis.com/auth/service.management.readonly,https://www.googleapis.com/auth/trace.append --tags=http-server --create-disk=auto-delete=yes,boot=yes,device-name=ciscfinal,image=projects/debian-cloud/global/images/debian-11-bullseye-v20220406,mode=rw,size=10,type=projects/cisc5550gcloud/zones/us-central1-a/diskTypes/pd-balanced --no-shielded-secure-boot --shielded-vtpm --shielded-integrity-monitoring --reservation-affinity=any
# gcloud compute firewall-rules create rule-allow-tcp-5000 --project cisc5550-demo --source-ranges 0.0.0.0/0 --target-tags http-server --allow tcp:5000

export TODO_API=`gcloud compute instances list --filter="name=ciscfinal" --format="value(EXTERNAL_IP)"`
# next, deploy the app that depens on api
# docker build -t zhouji2018/cisc5550todoapp --build-arg api_ip=${TODO_API} .
docker build -t cisc-front:v1 --build-arg api_ip=${TODO_API} . 
docker run -p 80:80 cisc-front:v1